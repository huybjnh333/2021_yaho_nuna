<div class="link_page">
  <div class="pagewrap">
    <ul>
     <li><a href="index.php"><i class="fa fa-home"></i>trang chủ</a> | <span class="active">Hỏi đáp</span></li></ul>
     <div class="clr"></div>
   </div>
 </div>
 <div class="page_conten_page">
  <?php include"menu_right.php";?>
  <div class="pagewrap">
    <ul class="list-unstyled">
      <li><a href="index.php?page=hoidap"><i class="fa fa-hand-o-left" aria-hidden="true"></i> Trở lại trang câu hỏi</a></li>
    </ul>
    <div class="title_news">
      <h2>Dùng khăn ướt liên tục có gây ung thư?</h2>
    </div>
    <div class="showText">
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>
    <div id="sharelink"> 
      <!-- AddThis Button BEGIN -->
      <div class="addthis_toolbox addthis_default_style "> <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_google_plusone" g:plusone:size="medium"></a> <a class="addthis_counter addthis_pill_style"></a> </div>
      <script type="text/javascript" src="//s7.addthis.com/js/250/addthis_widget.js#pubid=xa-502225fb496239a5"></script> 
      <!-- AddThis Button END --> 
    </div>
    <?php include"comment_face.php";?>
    <div class="box_page">
      <div class="title_page">
        <ul><h3 class="h_title" style="display: table;">Câu hỏi liên quan</h3>
        </ul>
      </div>
      <ul class="list-question">
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
        <li>
          <a href="index.php?page=hoidap_view"><i class="fa fa-angle-right"></i> Dùng khăn ướt liên tục có gây ung thư?</a>
        </li>
      </ul>
    </div>
  </div>
  <div class="clr"></div> 
</div>
<div class="link_page">
	<div class="pagewrap">
		<ul>
			<li><a href="index.php"><i class="fa fa-home"></i>trang chủ</a> | <a href="#">Tiện ích</a> | <span class="active">Dự đoán ngày sinh và số tuổi của bé</span></li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="page_conten_page">
	<?php include"menu_right.php";?>
	<div class="pagewrap">
		<div class="tin_left">
			<div class="tt_page_top tt_ngaysinh">
				<div class="col-md-6 col-lg-4">
					<div class="blog-item">
						<div class="img-box">
							<a href="index.php?page=ngaysinh_view" class="open-post">
								<img class="img-fluid" src="delete/tienich/1.png" alt="">
							</a>
						</div>
						<div class="text-box">
							<a href="index.php?page=ngaysinh_view" class="title-blog">
								<h5>Dự đoán ngày sinh của bé</h5>
							</a>
							<p>Bạn luôn nóng lòng chờ đến ngày được ôm bé trong tay. Bạn muốn biết khi nào thì bé chào đời.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-lg-4">
					<div class="blog-item">
						<div class="img-box">
							<a href="index.php?page=tuoibe_view" class="open-post">
								<img class="img-fluid" src="delete/tienich/2.png" alt="">
							</a>
						</div>
						<div class="text-box">
							<a href="index.php?page=tuoibe_view" class="title-blog">
								<h5>Xem tuổi của bé</h5>
							</a>
							<p>Bạn luôn nóng lòng chờ đến ngày được ôm bé trong tay. Bạn muốn biết khi nào thì bé chào đời.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="clr"></div>
		</div>
		<?php include"tin_right.php";?>
	</div>
	<div class="clr"></div>
</div>
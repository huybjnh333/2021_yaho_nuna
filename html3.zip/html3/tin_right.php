<div class="tin_right">
  <div class="box_right_pro_view">
    <div class="title_right_pro_view">BÀI VIẾT ĐƯỢC QUAN TÂM</div>
    <div class="blog-item">
      <div class="img-box">
        <a href="index.php?page=khuyenmai_view" class="open-post">
          <img class="img-fluid" src="delete/khuyenmai/1.jpg" alt="">
        </a>
      </div>
      <div class="text-box">
        <a href="index.php?page=khuyenmai_view" class="title-blog">
          <h5>SIÊU KHUYẾN MÃI “MUA 1 TẶNG 1” KHĂN ƯỚT NUNA</h5>
        </a>
      </div>
    </div>
    <div class="blog-item">
      <div class="img-box">
        <a href="index.php?page=khuyenmai_view" class="open-post">
          <img class="img-fluid" src="delete/khuyenmai/2.jpg" alt="">
        </a>
      </div>
      <div class="text-box">
        <a href="index.php?page=khuyenmai_view" class="title-blog">
          <h5>Mua 1 tặng 1 khi mua sản phẩm NUNA 100 miếng</h5>
        </a>
      </div>
    </div>
    <div class="blog-item">
      <div class="img-box">
        <a href="index.php?page=khuyenmai_view" class="open-post">
          <img class="img-fluid" src="delete/khuyenmai/3.jpg" alt="">
        </a>
      </div>
      <div class="text-box">
        <a href="index.php?page=khuyenmai_view" class="title-blog">
          <h5>ĐÓN HÈ VỚI KHUYẾN MÃI LỚN TẠI CO.OPMART CẢ NƯỚC</h5>
        </a>
      </div>
    </div>
  </div>
  <div class="box_right_pro_view">
    <a href="#"><img src="delete/khuyenmai/khuyenmai.jpg"></a>
  </div>
</div>
<div class="banner_detail" style="background-image: url('delete/banner/little-son.jpg');">
  <div class="link_page">
    <h2>Điểm bán</h2>
    <div class="pagewrap">
      <ul>
       <li><a href="index.php"><i class="fa fa-home"></i>trang chủ</a> | <span class="active">Điểm bán</span></li></ul>
       <div class="clr"></div>
     </div>
   </div>
 </div>
 <div class="page_conten_page pagewrap">
  <?php include"menu_right.php";?>
  <div class="flex hethongphanphoi">
        <div class="hethongphanphoi_id">
      <ul>
        <h3>LOTTE GÒ VẤP</h3>
        <div>
          <p>Số 18 Phan Văn Trị, Phường 10, Quận Gò Vấp</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
        <div class="hethongphanphoi_id">
      <ul>
        <h3>LOTTE TÂN BÌNH</h3>
        <div>
          <p>20 Cộng Hòa, Q. Tân Bình</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
        <div class="hethongphanphoi_id">
      <ul>
        <h3>LOTTE QUẬN 11</h3>
        <div>
          <p>968 Đường 3/2, Lầu 1, Tòa Nhà EverRich</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
        <div class="hethongphanphoi_id">
      <ul>
        <h3>LOTTE NAM SÀI GÒN</h3>
        <div>
          <p>470 Nguyễn Hữu Thọ, P. Tân Hưng, Q. 7</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
        <div class="hethongphanphoi_id">
      <ul>
        <h3>MM Mega Hiệp Phú</h3>
        <div>
          <p>Đường Tân Thới Hiệp, P. Tân Thới Hiệp, Q. 12, Tp. Hồ Chí Minh</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
        <div class="hethongphanphoi_id">
      <ul>
        <h3>MM Mega An Phú</h3>
        <div>
          <p>Phường An Phú, Quận 2, Tp. Hồ Chí Minh</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
        <div class="hethongphanphoi_id">
      <ul>
        <h3>MM Mega Bình Phú</h3>
        <div>
          <p>Đường Bình Phú, P. 11, Q. 6, Tp. Hồ Chí Minh</p>        </div>
      </ul>
      <div class="clr"></div>
    </div>
      </div>
  <div class="clr"></div>
</div>
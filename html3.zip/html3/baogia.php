<div class="banner_detail" style="background-image: url('delete/banner/original-detail.jpg');">
  <div class="link_page">
    <div class="pagewrap">
      <h2>Báo giá</h2>
      <ul>
       <li><a href="index.php"><i class="fa fa-home"></i>trang chủ</a> | <span class="active">Báo giá</span></li></ul>
       <div class="clr"></div>
     </div>
   </div>
 </div>
 <div class="page_conten_page pagewrap">
  <div class="tin_left">
    <div class="title_news">
      <h2>Báo giá thiết kế thi công nội thất</h2>
    </div>
    <div class="showText">
      <p style="text-align: justify;"><strong>Nội thất Konsept</strong>&nbsp;– Đơn vị nội thất hàng đầu trong lĩnh vực nội thất với 15 năm kinh nghiệm chuyên thiết kế thi công trọn gói nội thất gỗ công nghiệp đặc biệt là gỗ AN CƯỜNG – thương hiệu gỗ tốt nhất hiện nay với màu sắc đa dạng, độ cứng và chịu ẩm cao, độ bền sản phẩm lên đến 20 năm.</p>
      <p style="text-align: justify;">Nội thất Konsept với đội ngũ kiến trúc sư, tư vấn, giám sát giàu kinh nghiệm, <strong>Xưởng sản xuất rộng 1000m2 sở hữu dòng mày CNC hiện đại hiện đại nhất hiện nay, đội ngũ công nhân tay nghề cao</strong>&nbsp;chúng tôi cam kết gửi tới quý khách hàng những&nbsp;<strong>sản phẩm nội thất gỗ hoàn hảo nhất, giá thành tại nhà máy không phải qua trung gian</strong></p>
      <p style="text-align: justify;">Công ty chúng tôi với tiêu chí hoạt động lấy uy tín đặt lên hàng đầu,cam kết 100% chất liệu gỗ thương hiệu, khách hàng có thể qua xưởng kiểm tra gỗ đã đặt</p>
      <p style="text-align: justify;"><strong>Dưới đây là các bảng báo giá bao gồm báo giá:</strong></p>
      <ul>
        <li style="text-align: justify;"><strong>Báo giá thiết kế</strong> trọn gói gồm: Nội thất chung cư, nhà phố – liền kề, biệt thự, văn phòng…</li>
        <li>Trọn gói <strong>nội thất căn hộ 3 phòng ngủ</strong> (tương ứng với Diện tích 80m2 – 90m2 -100m2-110m2-120m2 -130m2)</li>
        <li style="text-align: justify;">Trọn gói <strong>nội thất căn hộ 2 phòng ngủ</strong> (tương ứng với diện tích từ 50m2-60m2-70m2)</li>
        <li style="text-align: justify;">Bảng báo giá với các chất liệu: gỗ ván dăm MFC, MDF, LAMINATE, ACRYLIC AN CƯỜNG – BÁO GIÁ HOÀN THIỆN ĐÃ BAO GỒM PHỤ KIỆN – LẮP ĐẶT</li>
      </ul>
      <div class="method-button-cart" style="margin-top: 30px;">
        <button type="button" title="Thanh toán" class="button btn-proceed-checkout btn-checkout" onclick="window.location = 'index.php?page=lienhe';"><span><span>Liên hệ báo giá</span></span></button>
      </div>
    </div>
    <div class="clr"></div>
    <div class="fl-post-meta fl-post-meta-bottom">
      <div class="fl-post-cats-tags">
        <i class="fa fa-tags"></i>
        <a href="#" rel="tag">Báo giá</a>
        <a href="index.php?page=gioithieu" rel="tag">Konsept</a>
        <a href="index.php?page=dichvu" rel="tag">Dịch vụ</a>
        <a href="index.php?page=lienhe" rel="tag">Liên hệ</a>
      </div>
    </div>
    <div id="sharelink"> 
      <!-- AddThis Button BEGIN -->
      <div class="addthis_toolbox addthis_default_style "> <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_google_plusone" g:plusone:size="medium"></a> <a class="addthis_counter addthis_pill_style"></a> </div>
      <script type="text/javascript" src="//s7.addthis.com/js/250/addthis_widget.js#pubid=xa-502225fb496239a5"></script> 
      <!-- AddThis Button END --> 
    </div>
  </div>
  <?php include"tin_right.php";?>
  <div class="clr"></div>
</div>
<div class="banner_detail" style="background-image: url('delete/banner/little-son.jpg');">
	<div class="link_page">
		<h2>Góc mẹ và bé</h2>
		<div class="pagewrap">
			<ul>
				<li><a href="index.php"><i class="fa fa-home"></i>Trang chủ</a> | <span class="active">Góc mẹ và bé</span></li></ul>
				<div class="clr"></div>
			</div>
		</div>
	</div>
	<div class="page_conten_page">
		<?php include"menu_right.php";?>
		<div class="pagewrap">
			<section class="dv-home-sanpham">
				<div class="pagewrap">
					<div class="col-lg-12 flex">
						<div class="col-lg-6">
							<div class="title_home align_left wow flipInX">
								<h2 class="tiltle">Thụ thai</h2>
							</div>
							<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
							<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
							<p class="read-more">
								<a href="index.php?page=mevabe">Xem thêm</a>
							</p>
						</div>
						<div class="col-lg-6">
							<img src="delete/trangchu/home1.jpg">
						</div>
					</div>
				</div>
				<div class="clr"></div>
			</section>
			<section class="dv-home-sanpham" style="padding-top: 50px;">
				<div class="pagewrap">
					<div class="col-lg-12 flex">
						<div class="col-lg-6">
							<img src="delete/trangchu/mebe-1.jpg">
						</div>
						<div class="col-lg-6">
							<div class="title_home align_left wow flipInX">
								<h2 class="tiltle">Mang thai</h2>
							</div>
							<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
							<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
							<p class="read-more">
								<a href="index.php?page=mevabe">Xem thêm</a>
							</p>
						</div>
					</div>
				</div>
				<div class="clr"></div>
			</section>
		</div>
		<div class="clr"></div>
	</div>
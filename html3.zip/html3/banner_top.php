<div class="bannerMain">
	<div class="banner owl-carousel owl-theme owl-custome" id="owl-banner">
		<li>
			<a href="index.php?page=sanpham"><img src="delete/banner/banner2.jpg"></a>
		</li>
		<li>
			<a href="index.php?page=sanpham"><img src="delete/banner/banner1.jpg"></a>
		</li>
	</div>
	<div class="clr"></div>
</div>
